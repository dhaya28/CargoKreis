import { useNavigate } from "react-router-dom";
import Footer from "./Footers";
import Myridecard from "./Myridecard";
import Navbar from "./Navbar";

const myrides = [
    {
        id: 1,
        departureTime: '11:00',
        arrivalTime: '21:30',
        departure: 'Mumbai',
        arrival: 'Bengaluru',
        duration: '10h30m',
        drivername: 'Arunprakash',
        status: 'Yet to Start',
    },
    {
        id: 2,
        departureTime: '11:00',
        arrivalTime: '21:30',
        departure: 'Mumbai',
        arrival: 'Bengaluru',
        duration: '10h30m',
        drivername: 'Arunprakash',
        status: 'In Transist',
    },
    {
        id: 3,
        departureTime: '11:00',
        arrivalTime: '21:30',
        departure: 'Mumbai',
        arrival: 'Bengaluru',
        duration: '10h30m',
        drivername: 'Arunprakash',
        status: 'Delivered',
    },
]

export default function Myrides() {
    const navigate = useNavigate();
    return (
        <div>
            <Navbar />
            <div style={{ width: '140vh', marginLeft: '225px' }}>
                {myrides.map((myride, index) => (
                    <div key={index} onClick={() => navigate(`/ridedetail/${myride.id}`)}>
                        <Myridecard myride={myride} />
                    </div>
                ))}
            </div>
            <Footer />
        </div>
    );
}